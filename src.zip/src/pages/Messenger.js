import Messages from "../components/Messages";

export default function Messenger(){
    return (
        <div>
            <h1>Messenger</h1>
            <Messages/>
        </div>

    );
}